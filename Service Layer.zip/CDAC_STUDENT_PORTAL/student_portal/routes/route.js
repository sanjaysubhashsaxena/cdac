var express = require('express');
var router = express.Router();
const List = require('../models/list'); 
const std  = require('../models/std_list');
const prf = require('../models/performance');
const Users = require('../models/login_detail');
const Feedback = require('../models/feedback');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
var mongoose = require('mongoose');
var db = require('../app').db;
var multer = require('multer');
var xlstojson = require("xls-to-json-lc");
var xlsxtojson = require("xlsx-to-json-lc");
var bcrypt = require('bcrypt');

var storage = multer.diskStorage({ //multers disk storage settings
        destination: function (req, file, cb) {
            cb(null, './uploads')
        },
        filename: function (req, file, cb) {
            var datetimestamp = Date.now();
            cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length -1])
        }
    });
    var upload = multer({ //multer settings
                    storage: storage,
                    fileFilter : function(req, file, callback) { //file filter
                        if (['xls', 'xlsx'].indexOf(file.originalname.split('.')[file.originalname.split('.').length-1]) === -1) {
                            return callback(new Error('Wrong extension type'));
                        }
                        callback(null, true);
                    }
                }).single('file');
    /** API path that will upload the files */
    router.post('/upload', function(req, res) {
        var exceltojson;
        upload(req,res,function(err){
            if(err){
                 res.json({error_code:1,err_desc:err});
                 return;
            }
            /** Multer gives us file info in req.file object */
            if(!req.file){
                res.json({error_code:1,err_desc:"No file passed"});
                return;
            }
            /** Check the extension of the incoming file and 
             *  use the appropriate module
             */
            if(req.file.originalname.split('.')[req.file.originalname.split('.').length-1] === 'xlsx'){
                exceltojson = xlsxtojson;
            } else {
                exceltojson = xlstojson;
            }
            try {
                exceltojson({
                    input: req.file.path,
                    output: null, //since we don't need output.json
                    lowerCaseHeaders:true
                }, function(err,result){
                    if(err) {
                        return res.json({error_code:1,err_desc:err, data: null});
                    } 
                    else
                    {
                     var res1;
                     new Promise(function(resolve, reject){
                         for(var i=0;i<result.length;i++)
                         {
                            res1=result[i];
                            var stdlist = new std({
                            rollno: res1.rollno,
                            name: res1.name,
                            prn: res1.prn,
                            course:res1.course 
                     });
                     stdlist.save((err)=>{
                        if(err){
                        console.log(err);
                        }
                        else{
                        console.log("std list successful!!!");
                    }   
                    });
                    }
                     resolve()
                    }).then(function(){
                        for(var i=0;i<result.length;i++)
                        {
                        res1=result[i];
                        var prfobj = new prf({
                            prn: res1.prn,
                            name : res1.name,
                            course: res1.course,
                            marks: []
                        });
                        prfobj.save((err)=>{
                            if(err)
                            console.log(err);
                            else
                            console.log("prf successful!");
                        })
                    }
                      }).then(function(){
                        for(var i=0;i<result.length;i++)
                        {
                            res1=result[i];
                            var logobj = new Users({
                            userid:res1.prn,
                            password:res1.prn,
                            dob :"",
                            flag : 0
                        });
                        logobj.save((err)=>{
                            if(err)
                            console.log(err);
                            else
                            console.log("log successful!");
                        })
                    }
                      }).catch(function(err){
                          if(err)
                          console.log("something went wrong!!!")
                      });
                         
                    
                    console.log(result);
                   // res.json({ data: result});
                    }
                });
            } catch (e){
                res.json({error_code:1,err_desc:"Corupted excel file"});
            }
        })
    }); 

//addMarks
router.post('/uploadmarks', function(req, res) {
    var exceltojson;
    upload(req,res,function(err){
        if(err){
             res.json({error_code:1,err_desc:err});
             return;
        }
        /** Multer gives us file info in req.file object */
        if(!req.file){
            res.json({error_code:1,err_desc:"No file passed"});
            return;
        }
        /** Check the extension of the incoming file and 
         *  use the appropriate module
         */
        if(req.file.originalname.split('.')[req.file.originalname.split('.').length-1] === 'xlsx'){
            exceltojson = xlsxtojson;
        } else {
            exceltojson = xlstojson;
        }
        try {
            exceltojson({
                input: req.file.path,
                output: null, //since we don't need output.json
                lowerCaseHeaders:true
            }, function(err,result){
                if(err) {
                    return res.json({error_code:1,err_desc:err, data: null});
                } 
                else
                {
                    for(var i=0;i<result.length;i++)
                    {
                        var res1=result[i];
                        console.log(res1.prn);
                                 console.log("inside");
                                var mk = { 
                                    "module": res1.module, 
                                    "lab": res1.lab, 
                                    "assignment": res1.assignment,
                                    "ccee":""
                                }
                                
                               prf.findOneAndUpdate({prn: res1.prn}, {$push: {marks: mk}},
                                function (error, success) {
                                       if (error) {
                                        console.log(error);
                                          } else {
                                            console.log(success);
                                          }
                                       });
                         
                    } 
                    res.json("hiii"); 
            }
            });
        } catch (e){
            res.json({error_code:1,err_desc:"Corupted excel file"});
        }
    })
}); 
        
    
//retrieving 
router.get('/show',(req,res,next)=>{
std.find(function(err, list){
     res.json(list);   
  });

});
router.post('/std',(req,res,next)=>{
    let newlist = new std({
      name: req.body.name,
      prn: req.body.prnno,
      course: req.body.course
    });
    newlist.save((err, std)=>{
        if(err)
        {
            res.json({msg:'failed to add'});
        }
        else{
            res.json({msg:'suceed to add'});
        }
    });
    });
    
    //login Validations and Redirect
router.post('/logs', function (req, res, next) {
     if (req.body.logemail && req.body.logpassword) {
      Users.authenticate(req.body.logemail, req.body.logpassword, function (error, user) {
          console.log("flagssss = " + user);
        if (error || !user) {
          console.log(req.body.logemail + "  "+ req.body.logpassword);
          var err = new Error('Wrong email or password.');
          err.status = 401;
          return next(err);
        } else {
          req.session.userId = user._id;
          if(user.flag != 0)
          {
           return res.redirect('/student_homepage');
          }
          else {
          return res.redirect('/resetpassword.html'); }
        }
      });
    } else {
      var err = new Error('All fields required.');
      err.status = 400;
      return next(err);
    }
  });
  
  // student_profile page
  router.get('/profile', function (req, res, next) {
    Users.findById(req.session.userId)
      .exec(function (error, user) {
        if (error) {
          return next(error);
        } else {
          if (user === null) {
            var err = new Error('Not authorized! Go back!');
            err.status = 400;
            return next(err);
          } else {
            return res.send('<h1>Name: </h1>' + user.userid + '<h2>Mail: </h2>' + user.password + '<br><h3>Session :</h3>' + req.session.userId + '<br><h3>flag value :</h3>'+ user.flag + '<br><a type="button" href="/logout">Logout</a>')

        }
        }
      });
  });
  
  //Student_HomePage
  router.get('/student_homepage', function(req,res,next){
    Users.findById(req.session.userId)
    .exec(function (error, user) {
      if (error) {
        return next(error);
      } else {
        if (user === null) {
          var err = new Error('Not authorized! Go back!');
          err.status = 400;
          return next(err);
        } else {
          return res.send('<h1 align="center">student home page</h1><br><br><h1>Name: </h1>' + user.userid + '<h2>Mail: </h2>' + user.password + '<br><h3>Session :</h3>' + req.session.userId + '<br><h3>flag value :</h3>'+ user.flag +'<br><a type="button" href="/logout">Logout</a>')
        }
      }
    });      
  });

//Reset_Password
router.post('/resetpass', function(req,res,next){

    Users.findById(req.session.userId)
    .exec(function (error, user) {
      if (error) {
        return next(error);
      } else {
        if (user === null) {
          var err = new Error('Not authorized! Go back!');
          err.status = 400;
          return next(err);
        } else 
        {   
            if(req.body.newpass===req.body.cnfpass && user.flag === 0 )
            {
                      console.log(user);
                      user.password = req.body.cnfpass;
                      user.flag += 1;
                      user.save();
                      return  res.redirect('/profile') ;
            }  
          else if(req.body.newpass===req.body.cnfpass && user.flag >= 1)
          {
            console.log(user);
            user.password = req.body.cnfpass;
            user.save();
            return  res.redirect('/student_homepage') ;
          }
            else
            return  res.redirect("ERRORRR!!!") ;
          

        }
       
      }
    });
});
  // GET for logout logout
  router.get('/logout', function (req, res, next) {
    if (req.session) {
      // delete session object
      req.session.destroy(function (err) {
        if (err) {
          return next(err);
        } else {
          return res.redirect('/');
        }
      });
    }
  });
  
  //addfeedback
  router.post('/addFeedback',function(req,res,next){
    Feedback.addFeedback(req.body.prn,req.body.name,req.body.course,req.body.values.split(','),function(err,success){
      if (err)
      {
        console.log("error occurred "+err);
        return next(err);
      }
      else
      {
        console.log(success);
        res.send("update successful");
      }
  
  
    });
  });

  //view feedbacks
  router.get('/viewfeedbacks',function(req,res,next){
    Feedback.findByCourse(req.query.course,function(err,result)
  {  var fb = [];
     var fb_det = [];
    if (err)
    {
      return err;
    }
    else {
     // console.log(result[0].feeds);
      for (var i=0;i<result.length;i++)
       { fb[i]=result[i].prn+" "+result[i].name+" "+result[i].course+" "
       +result[i].feeds;
  
         //console.log("feedback is of the form "+fb[i].concat(fb_det));
       }
  console.log("feedbacks are "+fb);
      res.send(fb);
    }
  });
  });

  //Student_View_performance
  router.get('/viewprf', function (req, res, next) {
    prf.find({prn:req.query.prn}).exec(function(err,perf){
        if (err) {
          return callback(err)
        } else if (!perf) {
          var err = new Error('User not found.');
          err.status = 401;
          res.send(err);
        }
        res.send(perf);
      
      });
      
    });
    
    //update performance
    router.post('/updateprf',function(req,res,next){
        console.log(req.body.prn + req.body.moduleName+req.body.values);

        //  console.log("in update"+req.body.values.split(',')[0]);
          prf.updateInternal(req.body.prn,req.body.moduleName,req.body.values,
          function(err,success){
            if (err)
            {
              console.log("error occurred "+err);
              return next(err);
            }
            else {
              console.log(success);
              res.send("update successful");
            }
          }
        );
    });

    router.get('/changeDatabase',function(req,res,next){
        db.close();
        mongoose.connect('mongodb://localhost:27017/'+req.query.dbName);
        db = mongoose.connection;
        db.on('connected',(err)=>{
        console.log(db);
        console.log("database changed ");
        if(err)
        return res.send(err);
        else {
        var data = db.collection(req.query.collectionName).find({});
         res.send(data);
        }
        });
        db.on('error',(err)=>{
            if(err)
            console.log('error'+err);
          });
      });
      

//add data
router.post('/List',(req,res,next)=>{
let newlist = new List({
  firstname: req.body.firstname,
  lastname: req.body.lastname,
  phone: req.body.phone
});

newlist.save((err, list)=>{
    if(err)
    {
        res.json({msg:'failed to add'});
    }
    else{
        res.json({msg:'suceed to add'});
    }
});
});

//delete
router.delete('/List/:id',(req,res,next)=>{
    List.remove({_id: req.params.id},function(err,result){
        if(err)
        {
            res.json(err);
        }
        else{
            res.json(result);
        }
    });
});
module.exports = router;







            // bcrypt.hash(req.body.cnfpass, 10, function (err, hash) {
            //     if (err) {
            //       return next(err);
            //     }
            //     else{
            //     req.body.cnfpass = hash;
            //     Users.update({userid:user.userid},{$set:{"password":req.body.cnfpass}},{new:true},function(err){
            //     if(err)
            //     {
            //     return next(err);
            //     }
            //     else
            //     {
            //     console.log("password changed successfully");
            //     if(user.flag === 0)
            //     return  res.redirect('/profile') ;
            //     else
            //     return  res.redirect('/student_homepage') ;
            //     }
            //    }); 
             // }
           // });
