var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyparser = require('body-parser');
var cors = require('cors');
var path = require('path');
var session = require('express-session');
var MongoStore = require('connect-mongo')(session);


//port no
const port = 3000;

//connect to mongodb
mongoose.connect('mongodb://localhost:27017/cdacproject');
var db = mongoose.connection;
//on connection
db.on('connected',()=>{
console.log('connected');
});

db.on('error',(err)=>{
    if(err)
    console.log('error'+err);
    });

    // caching disabled for every route
    app.use(function(req, res, next) {
      res.set('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
      next();
    });
    
    //use sessions for tracking logins
    app.use(session({
      secret: 'work hard',
      resave: true,
      saveUninitialized: false,
      store: new MongoStore({
        mongooseConnection: db
      })
    }));

const route = require('./routes/route');

// parse incoming requests
app.use(bodyparser.urlencoded({ extended: false }));

//adding middelware
app.use(cors());

//static files
app.use(express.static(path.join(__dirname,'public')));

//bodyparser
app.use(bodyparser.json());

//routes
app.use('/', route);


 app.get('/',(req,res)=>{
      res.send('ready');
 });

app.listen(port,()=>{
    console.log('server statrted at port:'+port);
});

//app.listen(port ,'192.168.43.246');