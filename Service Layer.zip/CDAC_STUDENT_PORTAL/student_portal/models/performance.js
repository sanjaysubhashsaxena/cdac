// var mongoose = require('mongoose');
// //var mrkschema = mongoose.Schema({ module:String, lab:Number, assignment:Number , ccee:Number});
// var listSchema = mongoose.Schema({
//     prn:{
//         type:Number,
//         required:true
//     },
//     course:{
//         type:String,
//         required:true
//     },
//     marks:[{ module:String, lab:Number, assignment:Number , ccee:Number}],
//     remarks:{
//         type:String
//     }
// });

// const Abc = module.exports = mongoose.model('performance', listSchema);

var mongoose = require('mongoose');
var PerformanceSchema = new mongoose.Schema({
    prn:{
        type:Number,
        required:true
    },
    name : {
        type : String,
        required : true
    },
    course:{
        type:String,
        required:true
    },
    marks:[{module:{type:String},
            assignment:{
                type: Number,
                min: 0, 
                max: 20},
      lab:{
        type: Number,
         min: 0, 
         max: 40
        },
    internalStatus:{type:String},
    cceemarks:{ 
        type: Number, 
        min: 0, 
        max: 40
    },
    cceeStatus:{type:String},
    totalMarks : { 
        type : Number,
        min : 0,
        max : 100
    },
    effectiveStatus:{type:String}}]
});
PerformanceSchema.statics.updateInternal = function(prn,moduleName,values,callback){
  console.log("about to update");
  Performance.findOneAndUpdate({"prn":prn,"marks.module":moduleName},
{$set:{"marks.$.lab":values}}, {new: true},function(err,docs){
  if (err)
  {
    return callback(err);
  }
  else {
  //  console.log(docs.moduleName.internalMarks);

    return callback(null,docs);
  }
});

}
// PerformanceSchema.statics.display = function(prn,callback){
// console.log("no module name");
// Performance.find({prn:Number(prn)}).exec(function(err,perf){
//   if (err) {
//     return callback(err)
//   } else if (!perf) {
//     var err = new Error('User not found.');
//     err.status = 401;
//     return callback(err);
//   }
//   return callback(null,perf);

// });
// }
var Performance = mongoose.model('Performance', PerformanceSchema,'performances');
module.exports = Performance;
