var mongoose = require('mongoose');

var listSchema = mongoose.Schema({
    firstname:{
        type:String,
        required:true
    },
    lastname:{
        type:String,
        required:true
    },
    phone:{
        type:String,
        required:true
    }
});

const Abc = module.exports = mongoose.model('pqrs', listSchema);

