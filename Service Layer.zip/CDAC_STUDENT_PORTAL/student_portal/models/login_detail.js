var mongoose = require('mongoose');
var bcrypt = require('bcrypt');

var UserSchema = mongoose.Schema({
    userid:{
        type:Number,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    // dob:{
    //   type:Date,
    //   required:true
      //yyyy-mm-dd
    //},
    flag:{
      type : Number,
      required:true,
    }
});

//authenticate input against database
UserSchema.statics.authenticate = function (userid, password, callback) {
    User.findOne({ userid: userid })
      .exec(function (err, user) {
        if (err) {
          return callback(err)
        } else if (!user) {
          var err = new Error('User not found.');
          err.status = 401;
          return callback(err);
        } else {//console.log("user found or not " + user);
        bcrypt.compare(password , user.password, function (err, result) {
          console.log(err,result);
          console.log(password + "   "+ user.password);
          if (result === true) {
            return callback(null, user);
          } else {
            return callback(err);
          }
        })
        // if(password === user.password)
        // return callback(null, user);
        // else 
        // return callback(err);
      }
      });
  }
  
  //hashing a password before saving it to the database
  UserSchema.pre('save', function (next) {
    var user = this;
    console.log("pre update bcryot " + user.password);
    bcrypt.hash(user.password, 10, function (err, hash) {
      if (err) {
        return next(err);
      }
      user.password = hash;
      next();
    })
  });
  
var User = mongoose.model('login_details', UserSchema);
module.exports = User;