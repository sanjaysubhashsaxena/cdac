var mongoose = require('mongoose');
var FeedbackSchema = new mongoose.Schema({
prn:{
    type:Number,
    required:true
},
name:{
  type:String,
  required:true
},
course:{
    type:String,
    required:true
},
feeds:[{subject:{type:String},date:{type:Date},details:{type:String}}],
    versionKey: false // You should be aware of the outcome after set to false

});
FeedbackSchema.statics.addFeedback=function(prn,name,course,feed,callback){
console.log("Feedback giver  is "+name);
var options = {upsert:true},
    query = {"prn":prn},
    update = {$set:{"prn":prn,"name":name,"course":course},$push:{feeds:{"subject":feed[0],"date":new Date(),"details":feed[1]}}};
Feedback.findOneAndUpdate(query,update,options,function(err,result){

  if (err)
  {
      callback(err,null);
  }
  else
  {
    console.log("document found and updated to "+result);
    return callback(null,result);
  }
});
}
FeedbackSchema.statics.findByCourse=function(course,callback,){
  console.log("course is "+course)
  Feedback.find({"course":course}).exec(function(err,result){
    if (err)
    {
      callback(err,null);
    }
    else
    {
      console.log(result);
     return callback(null,result);
    }
  });
}
var Feedback = mongoose.model('Feedback',FeedbackSchema,'feedbacks');
module.exports = Feedback;
