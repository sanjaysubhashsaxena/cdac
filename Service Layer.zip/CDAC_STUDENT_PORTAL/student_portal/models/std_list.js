var mongoose = require('mongoose');

var listSchema = mongoose.Schema({
    rollno:{
        type:Number,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    prn:{
        type:Number,
        required:true
    },
    course:{
        type:String,
        required:true
    }
});

const Abc = module.exports = mongoose.model('std_lists', listSchema);